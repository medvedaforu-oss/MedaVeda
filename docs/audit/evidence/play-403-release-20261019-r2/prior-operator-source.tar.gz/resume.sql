do $$
begin
  if (select count(*) from cron.job where jobid=8 and jobname='play-catalog-sync'
      and not active and schedule='* * * * *') <> 1 then
    raise exception 'Catalog cron state differs from the approved pause';
  end if;
  if exists(select 1 from public.play_price_sync where status in ('pending','running')
      or lease_id is not null or lease_until is not null)
     or exists(select 1 from net.http_request_queue
       where url='https://xbvenkfmesugrbjuufyw.supabase.co/functions/v1/sync-play-catalog')
     or exists(select 1 from cron.job_run_details where jobid=8 and status='running') then
    raise exception 'Resuming could execute another attempt; leave paused for a decision';
  end if;
  perform cron.alter_job(8, active := true);
end;
$$;
select jobid, jobname, active, schedule from cron.job where jobid=8;
