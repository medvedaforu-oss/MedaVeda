// Firestore collection: "quizTests"
//
// Product-based split: MCQ Quiz is always free, so it no longer needs a
// chapterId - tests are organized (and fetched) at the Subject level only.
export interface QuizTestQuestion {
  question: string;
  options: string[];
}

export interface QuizTest {
  id: string;
  title: string;
  subjectId: string;
  subjectTitle: string;
  yearId: string;
  yearTitle: string;
  order: number;
  active: boolean;
  questions: QuizTestQuestion[];
  // Added by 20261018100000; absent on older deployments/downloads.
  questionRevision?: number;
  // Added by 20260919120000_multi_course_and_referrals.sql - see types/course.ts.
  courseId: string;
}
