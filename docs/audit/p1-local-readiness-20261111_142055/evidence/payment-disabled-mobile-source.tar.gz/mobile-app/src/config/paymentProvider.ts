import Constants from "expo-constants";
import { Platform } from "react-native";
import * as Application from "expo-application";

export type PaymentProvider = "play" | "razorpay" | "disabled";

const extra = Constants.expoConfig?.extra;
const configuredProvider = extra?.medvedaPaymentProvider;
export const isNonplayTestBuild = Platform.OS === "android" &&
  Application.applicationId === "in.medveda.razorpaytest" &&
  extra?.medvedaDistribution === "non-play-internal-test" &&
  extra?.medvedaBuildTarget === "production-isolated-test" &&
  extra?.medvedaBuildProfile === "razorpay-internal-test" &&
  extra?.medvedaNonplayTestEnvironment === "production-isolated-razorpay-test-v1" &&
  process.env.EXPO_PUBLIC_SUPABASE_URL === "https://xbvenkfmesugrbjuufyw.supabase.co";

// Only the distinct installed non-Play test package may opt Android into the
// retained checkout. Stale/OTA config cannot opt the Play package into it.
// Keep historical receipt restoration independent of permission to start sales.
export const playRestorationEnabled = configuredProvider === "play" &&
  Platform.OS === "android" && Application.applicationId === "in.medveda.app";
const approvedUserChoice = extra?.medvedaIndiaUcbEnrolled === true &&
  (extra?.medvedaUcbTestAccepted === true ||
    (extra?.medvedaDistribution === "play-alpha-validation" &&
     process.env.EXPO_PUBLIC_SUPABASE_URL === "https://nsmsqsogedzohwboripd.supabase.co"));
export const paymentProvider: PaymentProvider =
  playRestorationEnabled && approvedUserChoice
    ? "play" : configuredProvider === "razorpay" && (Platform.OS !== "android" || isNonplayTestBuild)
    ? "razorpay" : "disabled";

// Separate build-time approval gates. Defaults and all existing Play profiles
// remain off until programme enrolment AND authorised Alpha acceptance exist.
export const userChoiceBillingEnabled = paymentProvider === "play" &&
  approvedUserChoice;
